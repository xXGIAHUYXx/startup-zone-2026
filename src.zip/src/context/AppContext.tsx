import React, { createContext, useContext, useState, useEffect } from 'react';
import type { 
  UserRole, 
  OrderRequest, 
  ChatMessage, 
  WorkshopPartner, 
  OwnerProposal, 
  ArtisanExecutionReport, 
  QcRecord,
  HandoverRecord,
  ClientApproval
} from '../types';
import { BAT_TRANG_WORKSHOPS, PRELOADED_SCENARIO_ORDERS } from '../data/mockData';

interface AppContextType {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  requests: OrderRequest[];
  messages: ChatMessage[];
  workshops: WorkshopPartner[];
  
  // Actions
  createRequest: (formData: any) => OrderRequest;
  dispatchToWorkshop: (requestId: string, workshopId: string, note: string) => void;
  artisanRespond: (requestId: string, decision: 'confirmed' | 'rejected', details: any) => void;
  ownerReviewAndSendProposal: (requestId: string, proposal: OwnerProposal) => void;
  customerApprove: (requestId: string, approvalData: { approvedBy: string; confirmedSampleOrSpecs: string; notes?: string }) => void;
  artisanReportExecution: (requestId: string, report: ArtisanExecutionReport) => void;
  ownerSubmitQc: (requestId: string, qc: QcRecord) => void;
  confirmHandover: (requestId: string, handover: HandoverRecord) => void;
  sendMessage: (content: string, senderRole: 'customer' | 'owner', senderName: string, relatedRequestId?: string) => void;
  resetAllData: () => void;
  preloadScenario: (scenarioId: string) => void;
}

const STORAGE_KEY_REQUESTS = 'mivl_requests_v2a';
const STORAGE_KEY_MESSAGES = 'mivl_messages_v2a';
const STORAGE_KEY_ROLE = 'mivl_role_v2a';

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Role state
  const [currentRole, setCurrentRoleState] = useState<UserRole>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ROLE);
    return (saved as UserRole) || 'guest';
  });

  const setCurrentRole = (role: UserRole) => {
    setCurrentRoleState(role);
    localStorage.setItem(STORAGE_KEY_ROLE, role);
  };

  // 2. Requests state (Khởi tạo hoàn toàn RỖNG theo Mục 5)
  const [requests, setRequests] = useState<OrderRequest[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_REQUESTS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_REQUESTS, JSON.stringify(requests));
  }, [requests]);

  // 3. Messages state (Chat 2 chiều)
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_MESSAGES);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_MESSAGES, JSON.stringify(messages));
  }, [messages]);

  const workshops = BAT_TRANG_WORKSHOPS;

  // Lần 1: Khách tạo yêu cầu -> Tự động sinh Creative Passport ngay
  const createRequest = (formData: any): OrderRequest => {
    const nextNum = requests.length + 1;
    const newId = `YC-${2600 + nextNum}`;
    const now = new Date();
    const formattedDate = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1).toString().padStart(2, '0')}/${now.getFullYear()} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const newReq: OrderRequest = {
      id: newId,
      serviceType: formData.serviceType,
      title: formData.title || (formData.serviceType === 'gifts' ? 'Đặt quà tặng gốm sứ Bát Tràng' : 'Tổ chức workshop trải nghiệm làm gốm'),
      contactName: formData.contactName,
      organization: formData.organization || '',
      contactPhone: formData.contactPhone,
      contactEmail: formData.contactEmail,
      description: formData.description,
      budget: formData.budget || 'Trao đổi cụ thể khi tư vấn',
      targetDate: formData.targetDate,
      workshopDetails: formData.serviceType === 'workshop' ? {
        participantsCount: Number(formData.participantsCount) || 20,
        plannedDate: formData.plannedDate || formData.targetDate,
        specialRequests: formData.specialRequests || ''
      } : undefined,
      giftsDetails: formData.serviceType === 'gifts' ? {
        quantity: Number(formData.quantity) || 20,
        productType: formData.productType || 'Bộ ly sứ cao cấp',
        personalizationNotes: formData.personalizationNotes || '',
        deliveryDate: formData.deliveryDate || formData.targetDate
      } : undefined,
      createdAt: formattedDate,
      status: 'cho_tiep_nhan',
      currentStep: 1,

      // Hồ sơ sáng tạo khởi tạo tức thì (Mục III)
      creativePassport: {
        passportId: `PASSPORT-${newId}`,
        orderId: newId,
        createdAt: formattedDate,
        serviceType: formData.serviceType,
        title: formData.title || (formData.serviceType === 'gifts' ? 'Quà tặng gốm thủ công' : 'Workshop trải nghiệm làm gốm'),
        clientName: formData.contactName,
        clientOrg: formData.organization || '',
        requirementSummary: formData.description,
        targetDate: formData.targetDate,
        workshopName: 'Đang kết nối xưởng Bát Tràng phù hợp',
        approvedDesignVersion: 'Chưa có dữ liệu (Đang chờ phương án)',
        executionStatus: 'Yêu cầu đã được xác nhận (Lần 1), đang chuẩn bị tư vấn',
        qcStatus: 'chua_co_du_lieu',
        handoverStatus: 'Đang ở giai đoạn xác nhận nhu cầu'
      }
    };

    setRequests(prev => [newReq, ...prev]);
    return newReq;
  };

  // Owner điều phối yêu cầu sang xưởng Bát Tràng
  const dispatchToWorkshop = (requestId: string, workshopId: string, note: string) => {
    const ws = workshops.find(w => w.id === workshopId);
    const now = new Date();
    const formattedDate = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1).toString().padStart(2, '0')}/${now.getFullYear()} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          assignedWorkshopId: workshopId,
          assignedWorkshopName: ws ? ws.name : 'Xưởng Bát Tràng',
          ownerDispatchNote: note,
          dispatchedAt: formattedDate,
          status: 'da_chuyen_xuong',
          artisanResponse: undefined,
          creativePassport: {
            ...req.creativePassport,
            workshopName: ws ? ws.name : req.creativePassport.workshopName,
            artisanLeader: ws ? ws.artisanLeader : undefined,
            executionStatus: `Đã chuyển yêu cầu tới ${ws ? ws.name : 'xưởng'}, chờ thẩm định năng lực & báo giá`
          }
        };
      }
      return req;
    }));
  };

  // Xưởng phản hồi (Đồng ý hoặc Từ chối có lý do)
  const artisanRespond = (requestId: string, decision: 'confirmed' | 'rejected', details: any) => {
    const now = new Date();
    const formattedDate = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1).toString().padStart(2, '0')}/${now.getFullYear()} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        if (decision === 'confirmed') {
          return {
            ...req,
            status: 'cho_owner_kiem_tra',
            artisanResponse: {
              decision: 'confirmed',
              proposedPrice: details.proposedPrice,
              proposedSchedule: details.proposedSchedule,
              technicalNotes: details.technicalNotes,
              respondedAt: formattedDate
            },
            creativePassport: {
              ...req.creativePassport,
              executionStatus: 'Xưởng đã phản hồi khả năng đáp ứng, Owner đang kiểm tra phương án'
            }
          };
        } else {
          return {
            ...req,
            status: 'xuong_tu_choi',
            artisanResponse: {
              decision: 'rejected',
              rejectionReason: details.rejectionReason || 'Xưởng hiện kín lò nung trong thời gian yêu cầu',
              respondedAt: formattedDate
            },
            creativePassport: {
              ...req.creativePassport,
              executionStatus: `Xưởng từ chối: ${details.rejectionReason || 'Kín lịch'}. Chờ Owner điều phối lại.`
            }
          };
        }
      }
      return req;
    }));
  };

  // Lần 2 - Bước 1: Owner kiểm tra, bóc tách giá xưởng vs phí Lab & gửi khách duyệt
  const ownerReviewAndSendProposal = (requestId: string, proposal: OwnerProposal) => {
    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          status: 'cho_khach_duyet',
          ownerProposal: proposal,
          creativePassport: {
            ...req.creativePassport,
            approvedDesignVersion: `${proposal.designOrProgramVersion} (Chờ khách duyệt)`,
            approvedScope: proposal.termsAndConditions,
            executionStatus: 'Phương án & báo giá đã chuẩn bị hoàn tất, đang chờ khách hàng phê duyệt'
          }
        };
      }
      return req;
    }));
  };

  // Lần 2 - Bước 2: Khách hàng phê duyệt báo giá và mẫu/chương trình thiết kế
  const customerApprove = (requestId: string, approvalData: { approvedBy: string; confirmedSampleOrSpecs: string; notes?: string }) => {
    const now = new Date();
    const formattedDate = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1).toString().padStart(2, '0')}/${now.getFullYear()} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const designVersion = req.ownerProposal?.designOrProgramVersion || `VER-${req.id}-v1`;
        const approval: ClientApproval = {
          approved: true,
          approvedAt: formattedDate,
          approvedBy: approvalData.approvedBy,
          approvedDesignVersion: designVersion,
          confirmedSampleOrSpecs: approvalData.confirmedSampleOrSpecs,
          notes: approvalData.notes || 'Khách hàng đã xác nhận điều kiện, báo giá và mẫu thiết kế'
        };

        return {
          ...req,
          status: 'dang_thuc_hien',
          currentStep: 2,
          clientApproval: approval,
          creativePassport: {
            ...req.creativePassport,
            approvedDesignVersion: designVersion,
            approvedScope: approvalData.confirmedSampleOrSpecs,
            approvedDate: formattedDate,
            approverName: approvalData.approvedBy,
            executionStatus: req.serviceType === 'workshop' 
              ? 'Khách đã phê duyệt chương trình, xưởng đang chuẩn bị công tác tổ chức workshop' 
              : 'Khách đã phê duyệt mẫu thiết kế & báo giá, xưởng đang tiến hành tạo hình và chế tác'
          }
        };
      }
      return req;
    }));
  };

  // Lần 3 - Bước 1: Xưởng báo cáo hoàn thành buổi workshop hoặc mẻ nung
  const artisanReportExecution = (requestId: string, report: ArtisanExecutionReport) => {
    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          status: 'cho_owner_qc', // Chờ Owner QC, KHÔNG được nhảy thẳng sang hoàn tất
          artisanExecutionReport: report,
          creativePassport: {
            ...req.creativePassport,
            executionStatus: req.serviceType === 'workshop'
              ? 'Buổi workshop đã được tổ chức xong, chờ Owner kiểm tra chất lượng (QC)'
              : 'Mẻ gốm đã hoàn thành chế tác, chờ Owner kiểm tra chất lượng (QC)',
            qcStatus: 'dang_kiem_tra'
          }
        };
      }
      return req;
    }));
  };

  // Lần 3 - Bước 2: Owner kiểm tra chất lượng (QC) và ghi nhận kết quả Đạt / Cần xử lý
  const ownerSubmitQc = (requestId: string, qc: QcRecord) => {
    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const isPassed = qc.result === 'dat';
        return {
          ...req,
          status: isPassed ? 'cho_khach_nghiem_thu' : 'can_xu_ly_qc',
          qcRecord: qc,
          creativePassport: {
            ...req.creativePassport,
            qcStatus: isPassed ? 'dat_chuan' : 'can_xu_ly',
            qcCheckedBy: qc.inspectorName,
            qcCheckedAt: qc.inspectedAt,
            qcNotes: qc.notes,
            executionStatus: isPassed
              ? 'QC kiểm tra đạt chuẩn. Chờ khách xác nhận nhận hàng hoặc hoàn tất dịch vụ.'
              : `QC chưa đạt yêu cầu (${qc.notes}). Xưởng cần xử lý bổ sung.`
          }
        };
      }
      return req;
    }));
  };

  // Lần 3 - Bước 3: Khách xác nhận nhận hàng / hoàn tất dịch vụ (hoặc ghi nhận chứng từ bên ngoài)
  const confirmHandover = (requestId: string, handover: HandoverRecord) => {
    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          status: 'hoan_thanh',
          currentStep: 3,
          handoverRecord: handover,
          creativePassport: {
            ...req.creativePassport,
            handoverConfirmedBy: handover.confirmedBy,
            handoverBasis: handover.documentBasis || 'Khách hàng xác nhận trực tuyến',
            handoverStatus: handover.notes,
            completedDate: handover.confirmedAt,
            executionStatus: 'Đã hoàn tất toàn bộ chu trình Một hồ sơ — Ba lần xác nhận'
          }
        };
      }
      return req;
    }));
  };

  // Gửi tin nhắn tư vấn 2 chiều
  const sendMessage = (content: string, senderRole: 'customer' | 'owner', senderName: string, relatedRequestId?: string) => {
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderRole,
      senderName,
      content,
      createdAt: timeStr,
      relatedRequestId
    };

    setMessages(prev => [...prev, newMsg]);
  };

  // Reset dữ liệu về trạng thái ban đầu rỗng sạch
  const resetAllData = () => {
    localStorage.removeItem(STORAGE_KEY_REQUESTS);
    localStorage.removeItem(STORAGE_KEY_MESSAGES);
    setRequests([]);
    setMessages([]);
    setCurrentRole('guest');
  };

  // Nạp kịch bản mẫu
  const preloadScenario = (scenarioId: string) => {
    if (scenarioId === 'scen-an-nam') {
      const order = PRELOADED_SCENARIO_ORDERS[0];
      setRequests(prev => {
        const filtered = prev.filter(r => r.id !== order.id);
        return [order, ...filtered];
      });
      setCurrentRole('customer');
    } else if (scenarioId === 'scen-sao-mai') {
      const order = PRELOADED_SCENARIO_ORDERS[1];
      setRequests(prev => {
        const filtered = prev.filter(r => r.id !== order.id);
        return [order, ...filtered];
      });
      setCurrentRole('owner');
    } else if (scenarioId === 'scen-artisan') {
      const order = PRELOADED_SCENARIO_ORDERS[0];
      setRequests(prev => {
        const filtered = prev.filter(r => r.id !== order.id);
        return [order, ...filtered];
      });
      setCurrentRole('artisan');
    }
  };

  return (
    <AppContext.Provider value={{
      currentRole,
      setCurrentRole,
      requests,
      messages,
      workshops,
      createRequest,
      dispatchToWorkshop,
      artisanRespond,
      ownerReviewAndSendProposal,
      customerApprove,
      artisanReportExecution,
      ownerSubmitQc,
      confirmHandover,
      sendMessage,
      resetAllData,
      preloadScenario
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
