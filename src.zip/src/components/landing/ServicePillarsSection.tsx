import React from 'react';
import { Card } from '../common/Card';
import { Button } from '../common/Button';
import type { ServiceType } from '../../types';
import { Compass, Gift, Users, Award, Clock, ArrowRight, Palette, CheckCircle2 } from 'lucide-react';

interface ServicePillarsSectionProps {
  onSelectService: (service: ServiceType) => void;
  onOpenQuickRequest: (service: ServiceType) => void;
}

export const ServicePillarsSection: React.FC<ServicePillarsSectionProps> = ({
  onSelectService,
  onOpenQuickRequest
}) => {
  return (
    <section id="services" className="py-16 sm:py-24 max-w-7xl mx-auto px-4 sm:px-6">
      
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-xs font-mono font-bold tracking-widest uppercase text-[#C85A32] block mb-2">
          DỊCH VỤ CỦA CHÚNG TÔI
        </span>
        <h2 className="font-heritage text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1E3A2F] mb-4">
          Hai lựa chọn dành cho bạn
        </h2>
        <p className="text-sm sm:text-base text-[#666666] leading-relaxed">
          Tùy theo nhu cầu của tổ chức hoặc cá nhân, bạn có thể tham gia trải nghiệm trực tiếp tại xưởng hoặc đặt chế tác quà tặng gốm sứ theo yêu cầu riêng.
        </p>
      </div>

      {/* Pillars Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10">
        
        {/* Service 1: Trải nghiệm làm gốm */}
        <div id="service-workshop" className="bg-white rounded-2xl border border-[#E6DFD3] hover:border-[#1E3A2F]/50 transition-all shadow-sm hover:shadow-lg flex flex-col justify-between p-6 sm:p-8">
          <div>
            {/* Tag info */}
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#1E3A2F]/10 text-[#1E3A2F] flex items-center gap-1.5">
                <Compass size={14} />
                Dành cho nhóm & đoàn thể
              </span>
              <span className="text-xs text-[#888888]">10 – 20 người / buổi</span>
            </div>

            <h3 className="font-heritage text-2xl sm:text-3xl font-bold text-[#1E3A2F] mb-3">
              Trải nghiệm làm gốm
            </h3>
            
            <p className="text-sm sm:text-base text-[#555555] leading-relaxed mb-6">
              Các buổi workshop thực tế tại Bát Tràng giúp thành viên trực tiếp chạm vào đất sét, ngồi bên bàn xoay truyền thống, tự tay vuốt nặn và sáng tạo tác phẩm gốm của riêng mình.
            </p>

            {/* Photo preview */}
            <div className="rounded-xl overflow-hidden aspect-[16/10] mb-6 relative group">
              <img
                src="https://images.unsplash.com/photo-1581783342308-f792dbdd27c5?auto=format&fit=crop&w=750&q=80"
                alt="Workshop trải nghiệm vuốt gốm Bát Tràng"
                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-4">
                <p className="text-xs sm:text-sm text-white font-medium">
                  Không gian xưởng mộc Bát Tràng yên bình ven sông Hồng
                </p>
              </div>
            </div>

            {/* Highlights */}
            <div className="space-y-3 mb-8 text-xs sm:text-sm text-[#444444]">
              <div className="flex items-start gap-3">
                <Users size={18} className="text-[#1E3A2F] shrink-0 mt-0.5" />
                <span>Thợ gốm Bát Tràng hướng dẫn tận tình theo nhóm nhỏ (tỷ lệ 1 thợ : 5 người).</span>
              </div>
              <div className="flex items-start gap-3">
                <Palette size={18} className="text-[#1E3A2F] shrink-0 mt-0.5" />
                <span>Tùy chỉnh chủ đề buổi học theo thông điệp hoặc dịp kỷ niệm của đơn vị bạn.</span>
              </div>
              <div className="flex items-start gap-3">
                <Clock size={18} className="text-[#1E3A2F] shrink-0 mt-0.5" />
                <span>Tác phẩm được xưởng tráng men, nung chín và gửi tận nơi sau 7–10 ngày.</span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="pt-4 border-t border-[#E6DFD3] flex flex-col sm:flex-row gap-3">
            <Button
              variant="forest"
              size="md"
              icon={<ArrowRight size={15} />}
              iconPosition="right"
              onClick={() => onOpenQuickRequest('workshop')}
              className="flex-1 text-sm font-semibold"
            >
              Đặt lịch trải nghiệm
            </Button>
            <Button
              variant="outline"
              size="md"
              onClick={() => onSelectService('workshop')}
              className="text-sm"
            >
              Xem chi tiết gói
            </Button>
          </div>
        </div>

        {/* Service 2: Quà tặng thủ công */}
        <div id="service-gifts" className="bg-white rounded-2xl border border-[#E6DFD3] hover:border-[#C85A32]/60 transition-all shadow-sm hover:shadow-lg flex flex-col justify-between p-6 sm:p-8">
          <div>
            {/* Tag info */}
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#C85A32]/10 text-[#C85A32] flex items-center gap-1.5">
                <Gift size={14} />
                Quà tặng theo lô
              </span>
              <span className="text-xs text-[#888888]">Từ 20 sản phẩm trở lên</span>
            </div>

            <h3 className="font-heritage text-2xl sm:text-3xl font-bold text-[#C85A32] mb-3">
              Quà tặng thủ công
            </h3>
            
            <p className="text-sm sm:text-base text-[#555555] leading-relaxed mb-6">
              Các bộ quà tặng gốm sứ Bát Tràng thiết kế riêng theo lô nhỏ cho doanh nghiệp, hội nghị hoặc quà tri ân — thể hiện sự trân trọng và nét văn hóa Việt sâu sắc.
            </p>

            {/* Photo preview */}
            <div className="rounded-xl overflow-hidden aspect-[16/10] mb-6 relative group">
              <img
                src="https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=750&q=80"
                alt="Bộ sản phẩm ly gốm quà tặng men hỏa biến Bát Tràng"
                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-4">
                <p className="text-xs sm:text-sm text-white font-medium">
                  Men hoả biến độc bản, men rạn ngà cổ điển hoặc men lam truyền thống
                </p>
              </div>
            </div>

            {/* Highlights */}
            <div className="space-y-3 mb-8 text-xs sm:text-sm text-[#444444]">
              <div className="flex items-start gap-3">
                <Award size={18} className="text-[#C85A32] shrink-0 mt-0.5" />
                <span>Khắc chìm logo, chữ kỷ niệm hoặc thông điệp tri ân dưới đáy hoặc thân sản phẩm.</span>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 size={18} className="text-[#C85A32] shrink-0 mt-0.5" />
                <span>Khách hàng được xem và duyệt mẫu thực tế trước khi xưởng tiến hành sản xuất mẻ chính.</span>
              </div>
              <div className="flex items-start gap-3">
                <Clock size={18} className="text-[#C85A32] shrink-0 mt-0.5" />
                <span>Đóng gói hộp giấy bồi thủ công mộc mạc, trang nhã, sẵn sàng trao tặng.</span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="pt-4 border-t border-[#E6DFD3] flex flex-col sm:flex-row gap-3">
            <Button
              variant="terracotta"
              size="md"
              icon={<ArrowRight size={15} />}
              iconPosition="right"
              onClick={() => onOpenQuickRequest('gifts')}
              className="flex-1 text-sm font-semibold"
            >
              Yêu cầu báo giá quà tặng
            </Button>
            <Button
              variant="outline"
              size="md"
              onClick={() => onSelectService('gifts')}
              className="text-sm"
            >
              Xem mẫu gợi ý
            </Button>
          </div>
        </div>

      </div>

    </section>
  );
};
