import React from 'react';
import { Button } from '../common/Button';
import type { ServiceType } from '../../types';
import { Compass, Gift, ArrowRight } from 'lucide-react';

interface HeroSectionProps {
  onSelectService: (service: ServiceType) => void;
  onOpenQuickRequest: (service?: ServiceType) => void;
  onExploreModel?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onSelectService,
  onOpenQuickRequest
}) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-18 lg:pt-20 lg:pb-28 bg-[#FDFBF7]">
      {/* Background soft ambient warmth */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#C85A32]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#1E3A2F]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Emotion & Clear Value Proposition */}
          <div className="lg:col-span-6 space-y-6 sm:space-y-8 text-left">
            
            {/* Subtle Tagline */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C85A32]/10 border border-[#C85A32]/20 text-[#C85A32] text-xs font-semibold tracking-wide">
              <span>Gốm Bát Tràng • Trải nghiệm & Quà tặng</span>
            </div>

            {/* Main Emotion Headline */}
            <h1 className="font-heritage text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-[#1E3A2F] leading-[1.2] tracking-tight">
              Chạm vào nghề Việt, <br className="hidden sm:inline" />
              tạo nên <span className="text-[#C85A32] italic">dấu ấn riêng.</span>
            </h1>

            {/* Concise User Description */}
            <p className="text-base sm:text-lg text-[#555555] leading-relaxed max-w-xl">
              Khám phá trải nghiệm làm gốm và quà tặng thủ công được thiết kế theo nhu cầu của bạn — từ những buổi workshop gắn kết đến các bộ quà tặng gốm sứ mộc mạc mang đậm tinh hoa làng nghề Bát Tràng.
            </p>

            {/* Dual Main CTAs */}
            <div className="pt-2 flex flex-col sm:flex-row gap-4">
              <Button
                variant="forest"
                size="lg"
                icon={<Compass size={18} />}
                onClick={() => onSelectService('workshop')}
                className="w-full sm:w-auto text-sm sm:text-base font-semibold px-6 py-3.5 shadow-sm hover:shadow-md"
              >
                Khám phá trải nghiệm
              </Button>

              <Button
                variant="terracotta"
                size="lg"
                icon={<Gift size={18} />}
                onClick={() => onOpenQuickRequest('gifts')}
                className="w-full sm:w-auto text-sm sm:text-base font-semibold px-6 py-3.5 shadow-sm hover:shadow-md"
              >
                Đặt quà theo yêu cầu
              </Button>
            </div>

            {/* Value Points in Human Language */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#E6DFD3] text-xs sm:text-sm text-[#555555]">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#C85A32]" />
                <span>Thiết kế theo số lượng và chủ đề riêng</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#1E3A2F]" />
                <span>Nghệ nhân xưởng Bát Tràng trực tiếp thực hiện</span>
              </div>
            </div>

          </div>

          {/* Right Column: Authentic Visual Imagery */}
          <div className="lg:col-span-6">
            <div className="relative">
              
              {/* Main Visual Image */}
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] sm:aspect-[14/10] shadow-2xl border border-[#E6DFD3] group">
                <img
                  src="https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=1000&q=85"
                  alt="Nghệ nhân gốm Bát Tràng tỉ mỉ tạo hình trên bàn xoay"
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-700"
                />
                
                {/* Visual Image Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex flex-col justify-end p-6 text-white">
                  <span className="text-xs font-mono uppercase tracking-widest text-amber-200 font-semibold mb-1">
                    Bát Tràng, Hà Nội
                  </span>
                  <p className="font-heritage text-lg sm:text-xl font-bold leading-snug">
                    Bàn tay thợ gốm, đất sét phù sa và sắc men truyền đời
                  </p>
                </div>
              </div>

              {/* Floating Small Experience Pill Card */}
              <div className="absolute -bottom-6 -left-4 sm:-bottom-8 sm:-left-8 bg-white/95 backdrop-blur-md p-4 rounded-xl shadow-xl border border-[#E6DFD3] max-w-[260px] hidden sm:block">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#C85A32]/10 text-[#C85A32] flex items-center justify-center font-bold text-sm shrink-0">
                    🏺
                  </div>
                  <div>
                    <strong className="text-xs font-bold text-[#1E3A2F] block">
                      Trải nghiệm thực tế
                    </strong>
                    <span className="text-[11px] text-[#666666]">
                      Tự tay vuốt gốm và nung tác phẩm mang về
                    </span>
                  </div>
                </div>
              </div>

              {/* Decorative Subtle Shadow Backing */}
              <div className="absolute -bottom-3 -right-3 w-full h-full bg-[#1E3A2F]/5 rounded-2xl -z-10 border border-[#1E3A2F]/10" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
