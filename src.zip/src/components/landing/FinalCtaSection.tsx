import React from 'react';
import { Button } from '../common/Button';
import type { ServiceType } from '../../types';
import { ArrowRight, Compass, Gift } from 'lucide-react';

interface FinalCtaSectionProps {
  onOpenQuickRequest: (service?: ServiceType) => void;
}

export const FinalCtaSection: React.FC<FinalCtaSectionProps> = ({
  onOpenQuickRequest
}) => {
  return (
    <section className="py-16 sm:py-20 bg-gradient-to-br from-[#1E3A2F] via-[#162E25] to-[#12241D] text-white relative overflow-hidden">
      {/* Decorative Warm Ambient Glow */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-[#C85A32]/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center relative z-10 space-y-6">
        <span className="text-xs font-mono uppercase tracking-widest text-[#DF957A] font-bold">
          BẮT ĐẦU CÙNG MADE IN VIETNAM LAB
        </span>

        <h2 className="font-heritage text-3xl sm:text-5xl font-bold leading-tight max-w-3xl mx-auto">
          Chạm vào đất sét, kể câu chuyện của riêng bạn
        </h2>

        <p className="text-sm sm:text-base text-white/80 max-w-xl mx-auto leading-relaxed">
          Dù bạn muốn tổ chức một buổi workshop gắn kết cho đội ngũ hay tìm kiếm món quà gốm sứ độc bản, chúng tôi luôn sẵn sàng hỗ trợ.
        </p>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            variant="terracotta"
            size="lg"
            icon={<Gift size={18} />}
            onClick={() => onOpenQuickRequest('gifts')}
            className="w-full sm:w-auto text-sm sm:text-base font-semibold px-7 py-3.5 shadow-md"
          >
            Yêu cầu báo giá quà tặng
          </Button>

          <Button
            variant="outline"
            size="lg"
            icon={<Compass size={18} />}
            onClick={() => onOpenQuickRequest('workshop')}
            className="w-full sm:w-auto text-sm sm:text-base font-semibold px-7 py-3.5 text-white border-white/30 hover:bg-white/10"
          >
            Đặt lịch trải nghiệm làm gốm
          </Button>
        </div>
      </div>
    </section>
  );
};
