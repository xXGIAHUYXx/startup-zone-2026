import React from 'react';
import { Button } from '../common/Button';
import { Send, CheckCircle2, Clock, ShieldCheck, HeartHandshake, Sparkles, ArrowRight } from 'lucide-react';

interface CustomerProcessSectionProps {
  onOpenQuickRequest?: () => void;
}

export const CoordinationModelSection: React.FC<CustomerProcessSectionProps> = ({
  onOpenQuickRequest
}) => {
  const steps = [
    {
      num: '01',
      title: 'Gửi yêu cầu của bạn',
      desc: 'Cho chúng tôi biết bạn cần tổ chức workshop hay làm quà tặng theo lô, quy mô bao nhiêu người/sản phẩm và thời gian mong muốn.',
      icon: Send
    },
    {
      num: '02',
      title: 'Xác nhận phương án & duyệt mẫu',
      desc: 'Xưởng Bát Tràng gửi phản hồi về khả năng thực hiện, mức giá và thời gian. Bạn xem ảnh mẫu thực tế trước khi xưởng bắt đầu làm hàng.',
      icon: ShieldCheck
    },
    {
      num: '03',
      title: 'Theo dõi thực hiện & nhận bàn giao',
      desc: 'Theo dõi tiến độ mẻ nung của xưởng, kiểm tra chất lượng thành phẩm và nhận bàn giao tận nơi kèm hồ sơ ghi nhận câu chuyện sản phẩm.',
      icon: Clock
    }
  ];

  const highlights = [
    {
      title: 'Đúng kỹ thuật truyền thống',
      desc: 'Mỗi sản phẩm đều do thợ gốm lành nghề tại Bát Tràng trực tiếp vuốt nặn, tráng men và nung lò đạt chuẩn.',
      icon: '🏺'
    },
    {
      title: 'Xem mẫu trước khi làm mẻ lớn',
      desc: 'Bạn luôn được duyệt mẫu thử thực tế trước khi xưởng tiến hành sản xuất cả lô, tránh hoàn toàn rủi ro sai lệch.',
      icon: '🔍'
    },
    {
      title: 'Chi phí minh bạch, không qua trung gian',
      desc: 'Báo giá rõ ràng, tôn trọng mức thù lao xứng đáng của thợ gốm và không phát sinh phụ phí vô lý.',
      icon: '🌿'
    }
  ];

  return (
    <section id="coordination-model" className="py-16 sm:py-24 bg-[#F7F2E8]/60 border-y border-[#E6DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-mono font-bold tracking-widest uppercase text-[#1E3A2F] block mb-2">
            QUY TRÌNH ĐẶT DỊCH VỤ
          </span>
          <h2 className="font-heritage text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1E3A2F] mb-4">
            Đơn giản, minh bạch và an tâm
          </h2>
          <p className="text-sm sm:text-base text-[#666666] leading-relaxed">
            Chúng tôi đồng hành cùng bạn từ ý tưởng ban đầu cho đến khi tác phẩm gốm hoàn thiện đến tay bạn.
          </p>
        </div>

        {/* 3 Simple Customer Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 mb-16">
          {steps.map((st, i) => {
            const Icon = st.icon;
            return (
              <div
                key={i}
                className="bg-white rounded-2xl p-6 sm:p-7 border border-[#E6DFD3] shadow-xs relative flex flex-col justify-between hover:border-[#C85A32]/40 transition-all hover:shadow-md group"
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <span className="text-3xl font-heritage font-bold text-[#C85A32]/30 group-hover:text-[#C85A32] transition-colors">
                      {st.num}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-[#FAF8F5] border border-[#E6DFD3] flex items-center justify-center text-[#1E3A2F]">
                      <Icon size={18} />
                    </div>
                  </div>

                  <h3 className="font-heritage text-xl font-bold text-[#1E3A2F] mb-2.5">
                    {st.title}
                  </h3>

                  <p className="text-sm text-[#555555] leading-relaxed">
                    {st.desc}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-black/5 flex items-center text-xs text-[#888888]">
                  <span>Bước {i + 1} trong quy trình</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Customer Benefits Cards */}
        <div className="bg-white rounded-2xl p-6 sm:p-10 border border-[#E6DFD3] shadow-sm">
          <div className="text-center max-w-xl mx-auto mb-8">
            <h3 className="font-heritage text-2xl sm:text-3xl font-bold text-[#1E3A2F] mb-2">
              Tại sao bạn có thể hoàn toàn yên tâm?
            </h3>
            <p className="text-xs sm:text-sm text-[#666666]">
              Những cam kết thiết thực dành cho người đặt trải nghiệm và quà tặng thủ công
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {highlights.map((item, idx) => (
              <div key={idx} className="p-5 rounded-xl bg-[#FAF8F5] border border-[#E6DFD3] space-y-2">
                <span className="text-2xl block mb-2">{item.icon}</span>
                <h4 className="font-heritage text-lg font-bold text-[#1E3A2F]">
                  {item.title}
                </h4>
                <p className="text-xs sm:text-sm text-[#555555] leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>

          {onOpenQuickRequest && (
            <div className="mt-8 pt-6 border-t border-[#E6DFD3] text-center">
              <Button
                variant="terracotta"
                size="md"
                onClick={onOpenQuickRequest}
                icon={<ArrowRight size={16} />}
                iconPosition="right"
                className="text-sm font-semibold"
              >
                Bắt đầu gửi yêu cầu ngay
              </Button>
            </div>
          )}
        </div>

      </div>
    </section>
  );
};
