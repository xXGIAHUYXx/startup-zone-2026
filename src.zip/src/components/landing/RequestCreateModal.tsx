import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import type { ServiceType } from '../../types';
import { Compass, Gift, ArrowRight, CheckCircle2, ArrowLeft, ShieldAlert } from 'lucide-react';

interface RequestCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialService?: ServiceType;
  onSubmit: (formData: any) => void;
}

export const RequestCreateModal: React.FC<RequestCreateModalProps> = ({
  isOpen,
  onClose,
  initialService = 'gifts',
  onSubmit
}) => {
  const [step, setStep] = useState<'form' | 'review'>('form');
  const [serviceType, setServiceType] = useState<ServiceType>(initialService);

  // Form Fields
  const [contactName, setContactName] = useState('');
  const [organization, setOrganization] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [description, setDescription] = useState('');
  const [budget, setBudget] = useState('');
  const [targetDate, setTargetDate] = useState('');

  // Workshop specifics
  const [participantsCount, setParticipantsCount] = useState('15');
  const [plannedDate, setPlannedDate] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');

  // Gifts specifics
  const [quantity, setQuantity] = useState('20');
  const [productType, setProductType] = useState('Bộ ly gốm men hỏa biến');
  const [personalizationNotes, setPersonalizationNotes] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');

  // Validation errors
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!contactName.trim()) errs.contactName = 'Vui lòng nhập tên người liên hệ';
    if (!contactPhone.trim()) errs.contactPhone = 'Vui lòng nhập số điện thoại liên hệ';
    if (!contactEmail.trim()) errs.contactEmail = 'Vui lòng nhập email liên hệ';
    if (!description.trim()) errs.description = 'Vui lòng nhập mô tả nhu cầu';
    if (!targetDate.trim()) errs.targetDate = 'Vui lòng nhập thời hạn mong muốn';

    if (serviceType === 'workshop') {
      if (!participantsCount || Number(participantsCount) <= 0) {
        errs.participantsCount = 'Vui lòng nhập số lượng người tham gia';
      }
    } else {
      if (!quantity || Number(quantity) <= 0) {
        errs.quantity = 'Vui lòng nhập số lượng sản phẩm';
      }
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNextToReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      setStep('review');
    }
  };

  const handleFinalSubmit = () => {
    if (isSubmitting) return;
    setIsSubmitting(true);

    const data = {
      serviceType,
      contactName,
      organization,
      contactPhone,
      contactEmail,
      description,
      budget: budget || 'Trao đổi cụ thể khi tư vấn',
      targetDate,
      participantsCount,
      plannedDate: plannedDate || targetDate,
      specialRequests,
      quantity,
      productType,
      personalizationNotes,
      deliveryDate: deliveryDate || targetDate
    };

    onSubmit(data);
    setTimeout(() => {
      setIsSubmitting(false);
      handleClose();
    }, 200);
  };

  const handleClose = () => {
    setStep('form');
    setErrors({});
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title={step === 'form' ? 'Gửi Yêu Cầu Dịch Vụ Mới' : 'Xác Nhận Lại Thông Tin Yêu Cầu'}
      subtitle={
        step === 'form'
          ? 'Điền thông tin để đội ngũ điều phối kết nối bạn với xưởng Bát Tràng phù hợp'
          : 'Vui lòng kiểm tra lại thông tin trước khi chính thức gửi yêu cầu'
      }
      maxWidth="2xl"
    >
      {step === 'form' && (
        <form onSubmit={handleNextToReview} className="space-y-5">
          {/* Service toggle */}
          <div>
            <label className="block text-xs font-bold text-[#1E3A2F] mb-2 uppercase tracking-wider">
              Chọn Dịch Vụ Quan Tâm
            </label>
            <div className="grid grid-cols-2 gap-3.5">
              <button
                type="button"
                onClick={() => setServiceType('gifts')}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  serviceType === 'gifts'
                    ? 'border-[#C85A32] bg-[#FDF6F3] text-[#C85A32] shadow-xs'
                    : 'border-[#E6DFD3] hover:border-black/20 text-[#666666]'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <Gift size={20} />
                  {serviceType === 'gifts' && <CheckCircle2 size={16} />}
                </div>
                <strong className="text-sm font-bold block text-[#222222] font-heritage">
                  Quà tặng thủ công
                </strong>
                <span className="text-xs text-[#666666]">
                  Lô sản phẩm gốm sứ thiết kế theo yêu cầu
                </span>
              </button>

              <button
                type="button"
                onClick={() => setServiceType('workshop')}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  serviceType === 'workshop'
                    ? 'border-[#1E3A2F] bg-[#F2F7F4] text-[#1E3A2F] shadow-xs'
                    : 'border-[#E6DFD3] hover:border-black/20 text-[#666666]'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <Compass size={20} />
                  {serviceType === 'workshop' && <CheckCircle2 size={16} />}
                </div>
                <strong className="text-sm font-bold block text-[#222222] font-heritage">
                  Trải nghiệm làm gốm
                </strong>
                <span className="text-xs text-[#666666]">
                  Workshop vuốt nặn trực tiếp tại Bát Tràng
                </span>
              </button>
            </div>
          </div>

          {/* Section: Thông tin người liên hệ */}
          <div className="pt-2 border-t border-[#E6DFD3]">
            <span className="text-xs font-bold text-[#1E3A2F] uppercase tracking-wider block mb-3">
              Thông Tin Người Liên Hệ
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#444444] mb-1">
                  Tên người liên hệ <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="Ví dụ: Nguyễn Văn An"
                  className={`w-full text-xs sm:text-sm p-3 rounded-xl border bg-white focus:outline-none ${
                    errors.contactName ? 'border-red-500' : 'border-[#D4C8B5] focus:border-[#C85A32]'
                  }`}
                />
                {errors.contactName && <span className="text-[11px] text-red-500 mt-1 block">{errors.contactName}</span>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#444444] mb-1">
                  Tên tổ chức / Doanh nghiệp <span className="text-xs text-[#888888] font-normal">(không bắt buộc)</span>
                </label>
                <input
                  type="text"
                  value={organization}
                  onChange={(e) => setOrganization(e.target.value)}
                  placeholder="Ví dụ: Công ty TNHH Sáng Tạo Việt"
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-[#D4C8B5] bg-white focus:outline-none focus:border-[#C85A32]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#444444] mb-1">
                  Số điện thoại <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="Ví dụ: 0912 345 678"
                  className={`w-full text-xs sm:text-sm p-3 rounded-xl border bg-white focus:outline-none ${
                    errors.contactPhone ? 'border-red-500' : 'border-[#D4C8B5] focus:border-[#C85A32]'
                  }`}
                />
                {errors.contactPhone && <span className="text-[11px] text-red-500 mt-1 block">{errors.contactPhone}</span>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#444444] mb-1">
                  Email liên hệ <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  placeholder="Ví dụ: an.nguyen@email.com"
                  className={`w-full text-xs sm:text-sm p-3 rounded-xl border bg-white focus:outline-none ${
                    errors.contactEmail ? 'border-red-500' : 'border-[#D4C8B5] focus:border-[#C85A32]'
                  }`}
                />
                {errors.contactEmail && <span className="text-[11px] text-red-500 mt-1 block">{errors.contactEmail}</span>}
              </div>
            </div>
          </div>

          {/* Section: Thông tin chi tiết dịch vụ */}
          <div className="pt-2 border-t border-[#E6DFD3]">
            <span className="text-xs font-bold text-[#1E3A2F] uppercase tracking-wider block mb-3">
              Chi Tiết Yêu Cầu ({serviceType === 'gifts' ? 'Quà Tặng' : 'Workshop'})
            </span>

            {serviceType === 'gifts' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#444444] mb-1">
                    Số lượng sản phẩm dự kiến <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    placeholder="Ví dụ: 20"
                    className={`w-full text-xs sm:text-sm p-3 rounded-xl border bg-white focus:outline-none ${
                      errors.quantity ? 'border-red-500' : 'border-[#D4C8B5] focus:border-[#C85A32]'
                    }`}
                  />
                  {errors.quantity && <span className="text-[11px] text-red-500 mt-1 block">{errors.quantity}</span>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#444444] mb-1">
                    Loại sản phẩm quan tâm
                  </label>
                  <input
                    type="text"
                    value={productType}
                    onChange={(e) => setProductType(e.target.value)}
                    placeholder="Ví dụ: Bộ ly sứ men hỏa biến, Bình hoa men rạn..."
                    className="w-full text-xs sm:text-sm p-3 rounded-xl border border-[#D4C8B5] bg-white focus:outline-none focus:border-[#C85A32]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-[#444444] mb-1">
                    Nội dung cá nhân hóa (nếu có)
                  </label>
                  <input
                    type="text"
                    value={personalizationNotes}
                    onChange={(e) => setPersonalizationNotes(e.target.value)}
                    placeholder="Ví dụ: Khắc chìm logo ở đáy ly, đóng hộp giấy bồi lót lụa..."
                    className="w-full text-xs sm:text-sm p-3 rounded-xl border border-[#D4C8B5] bg-white focus:outline-none focus:border-[#C85A32]"
                  />
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#444444] mb-1">
                    Số người tham gia dự kiến <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={participantsCount}
                    onChange={(e) => setParticipantsCount(e.target.value)}
                    placeholder="Ví dụ: 15"
                    className={`w-full text-xs sm:text-sm p-3 rounded-xl border bg-white focus:outline-none ${
                      errors.participantsCount ? 'border-red-500' : 'border-[#D4C8B5] focus:border-[#C85A32]'
                    }`}
                  />
                  {errors.participantsCount && <span className="text-[11px] text-red-500 mt-1 block">{errors.participantsCount}</span>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#444444] mb-1">
                    Ngày dự kiến tổ chức
                  </label>
                  <input
                    type="text"
                    value={plannedDate}
                    onChange={(e) => setPlannedDate(e.target.value)}
                    placeholder="Ví dụ: Thứ Bảy, 15/11/2026"
                    className="w-full text-xs sm:text-sm p-3 rounded-xl border border-[#D4C8B5] bg-white focus:outline-none focus:border-[#C85A32]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-[#444444] mb-1">
                    Yêu cầu tổ chức hoạt động
                  </label>
                  <input
                    type="text"
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    placeholder="Ví dụ: Cần không gian yên tĩnh, có thời gian thưởng trà và kèm cặp riêng 1:5..."
                    className="w-full text-xs sm:text-sm p-3 rounded-xl border border-[#D4C8B5] bg-white focus:outline-none focus:border-[#C85A32]"
                  />
                </div>
              </div>
            )}

            {/* Common: Description & Target Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
              <div>
                <label className="block text-xs font-semibold text-[#444444] mb-1">
                  Thời hạn hoàn thành / sự kiện <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  placeholder="Ví dụ: 20/11/2026"
                  className={`w-full text-xs sm:text-sm p-3 rounded-xl border bg-white focus:outline-none ${
                    errors.targetDate ? 'border-red-500' : 'border-[#D4C8B5] focus:border-[#C85A32]'
                  }`}
                />
                {errors.targetDate && <span className="text-[11px] text-red-500 mt-1 block">{errors.targetDate}</span>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#444444] mb-1">
                  Ngân sách dự kiến <span className="text-xs text-[#888888] font-normal">(nếu có)</span>
                </label>
                <input
                  type="text"
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  placeholder="Ví dụ: 5.000.000 - 8.000.000 VNĐ"
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-[#D4C8B5] bg-white focus:outline-none focus:border-[#C85A32]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-[#444444] mb-1">
                  Mô tả nhu cầu chi tiết <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Mô tả cụ thể mong muốn về màu men, phong cách, mục đích sử dụng..."
                  className={`w-full text-xs sm:text-sm p-3 rounded-xl border bg-white focus:outline-none ${
                    errors.description ? 'border-red-500' : 'border-[#D4C8B5] focus:border-[#C85A32]'
                  }`}
                />
                {errors.description && <span className="text-[11px] text-red-500 mt-1 block">{errors.description}</span>}
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-[#E6DFD3] flex items-center justify-end gap-3">
            <Button variant="ghost" size="md" type="button" onClick={handleClose}>
              Hủy bỏ
            </Button>
            <Button
              variant="terracotta"
              size="md"
              type="submit"
              icon={<ArrowRight size={15} />}
              iconPosition="right"
              className="text-xs sm:text-sm font-semibold"
            >
              Xem lại trước khi gửi
            </Button>
          </div>
        </form>
      )}

      {/* Step 2: Review before submit */}
      {step === 'review' && (
        <div className="space-y-5">
          <div className="p-4 bg-[#FAF8F5] rounded-xl border border-[#E6DFD3] space-y-3 text-xs sm:text-sm">
            <div className="flex items-center justify-between pb-2 border-b border-[#E6DFD3]">
              <span className="text-[#888888]">Dịch vụ:</span>
              <strong className="text-[#1E3A2F] font-bold">
                {serviceType === 'gifts' ? 'Quà tặng thủ công theo lô' : 'Trải nghiệm làm gốm Bát Tràng'}
              </strong>
            </div>

            <div className="grid grid-cols-2 gap-2 py-1">
              <div>
                <span className="text-[#888888] block text-xs">Người liên hệ:</span>
                <span className="font-semibold text-[#222222]">{contactName}</span>
              </div>
              <div>
                <span className="text-[#888888] block text-xs">Tổ chức:</span>
                <span className="font-semibold text-[#222222]">{organization || 'Cá nhân'}</span>
              </div>
              <div>
                <span className="text-[#888888] block text-xs">Số điện thoại:</span>
                <span className="font-semibold text-[#222222]">{contactPhone}</span>
              </div>
              <div>
                <span className="text-[#888888] block text-xs">Email:</span>
                <span className="font-semibold text-[#222222]">{contactEmail}</span>
              </div>
            </div>

            <div className="py-2 border-t border-[#E6DFD3] space-y-1.5">
              {serviceType === 'gifts' ? (
                <>
                  <div className="flex justify-between">
                    <span className="text-[#888888]">Số lượng:</span>
                    <strong className="text-[#222222]">{quantity} sản phẩm</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888888]">Loại sản phẩm:</span>
                    <span className="text-[#222222]">{productType}</span>
                  </div>
                  {personalizationNotes && (
                    <div className="flex justify-between">
                      <span className="text-[#888888]">Cá nhân hóa:</span>
                      <span className="text-[#222222]">{personalizationNotes}</span>
                    </div>
                  )}
                </>
              ) : (
                <>
                  <div className="flex justify-between">
                    <span className="text-[#888888]">Số người tham gia:</span>
                    <strong className="text-[#222222]">{participantsCount} người</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888888]">Ngày dự kiến:</span>
                    <span className="text-[#222222]">{plannedDate || targetDate}</span>
                  </div>
                  {specialRequests && (
                    <div className="flex justify-between">
                      <span className="text-[#888888]">Yêu cầu:</span>
                      <span className="text-[#222222]">{specialRequests}</span>
                    </div>
                  )}
                </>
              )}
              <div className="flex justify-between">
                <span className="text-[#888888]">Thời hạn:</span>
                <span className="text-[#222222]">{targetDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#888888]">Ngân sách:</span>
                <span className="text-[#C85A32] font-semibold">{budget}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-[#E6DFD3]">
              <span className="text-[#888888] block text-xs mb-1">Mô tả nhu cầu:</span>
              <p className="text-[#333333] leading-relaxed text-xs">
                {description}
              </p>
            </div>
          </div>

          <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-150 text-xs text-blue-900 leading-relaxed">
            Yêu cầu sau khi gửi sẽ xuất hiện trong mục <strong>Đơn hàng của tôi</strong> với trạng thái <em>Chờ tiếp nhận</em>. Đội ngũ điều phối viên sẽ kiểm tra và liên hệ trao đổi phương án với xưởng Bát Tràng phù hợp nhất.
          </div>

          <div className="pt-3 border-t border-[#E6DFD3] flex items-center justify-between gap-3">
            <Button
              variant="outline"
              size="md"
              type="button"
              icon={<ArrowLeft size={14} />}
              onClick={() => setStep('form')}
            >
              Sửa lại thông tin
            </Button>

            <Button
              variant="terracotta"
              size="md"
              type="button"
              icon={<CheckCircle2 size={16} />}
              onClick={handleFinalSubmit}
              disabled={isSubmitting}
              className="text-xs sm:text-sm font-semibold"
            >
              {isSubmitting ? 'Đang gửi...' : 'Xác nhận gửi yêu cầu'}
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
};
