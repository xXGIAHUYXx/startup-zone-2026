import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hoverable?: boolean;
  bordered?: boolean;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({
  children,
  className = '',
  hoverable = false,
  bordered = true,
  onClick
}) => {
  return (
    <div
      onClick={onClick}
      className={`
        bg-white rounded-xl overflow-hidden
        ${bordered ? 'border border-[#E6DFD3]/80' : ''}
        ${hoverable ? 'transition-all duration-200 hover:-translate-y-1 hover:shadow-lg hover:shadow-[#1E3A2F]/5 hover:border-[#C85A32]/40 cursor-pointer' : 'shadow-sm'}
        ${className}
      `}
    >
      {children}
    </div>
  );
};
