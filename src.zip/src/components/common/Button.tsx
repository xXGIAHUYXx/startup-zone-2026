import React from 'react';

type ButtonVariant = 'terracotta' | 'forest' | 'secondary' | 'outline' | 'ghost';
type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  loading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'terracotta',
  size = 'md',
  icon,
  iconPosition = 'left',
  loading = false,
  className = '',
  disabled,
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed select-none active:scale-[0.98]';

  const sizeStyles: Record<ButtonSize, string> = {
    sm: 'text-xs px-3 py-1.5 gap-1.5',
    md: 'text-sm px-4 py-2.5 gap-2',
    lg: 'text-base px-6 py-3.5 gap-2.5'
  };

  const variantStyles: Record<ButtonVariant, string> = {
    terracotta: 'bg-[#C85A32] text-white hover:bg-[#B84A28] shadow-sm hover:shadow-md hover:shadow-[#C85A32]/20',
    forest: 'bg-[#1E3A2F] text-white hover:bg-[#162E25] shadow-sm hover:shadow-md hover:shadow-[#1E3A2F]/25',
    secondary: 'bg-[#E6DFD3] text-[#222222] hover:bg-[#D4C8B5]',
    outline: 'bg-transparent text-[#222222] border border-[#D4C8B5] hover:border-[#C85A32] hover:text-[#C85A32] hover:bg-white',
    ghost: 'bg-transparent text-[#666666] hover:text-[#222222] hover:bg-black/5'
  };

  return (
    <button
      className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
      ) : (
        <>
          {icon && iconPosition === 'left' && <span className="shrink-0">{icon}</span>}
          <span>{children}</span>
          {icon && iconPosition === 'right' && <span className="shrink-0">{icon}</span>}
        </>
      )}
    </button>
  );
};
