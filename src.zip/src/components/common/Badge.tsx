import React from 'react';

type BadgeVariant = 'terracotta' | 'forest' | 'sand' | 'charcoal' | 'gold' | 'outline' | 'demo';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
  size?: 'sm' | 'md';
  icon?: React.ReactNode;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'terracotta',
  className = '',
  size = 'md',
  icon
}) => {
  const baseStyles = 'inline-flex items-center gap-1.5 font-medium rounded-full transition-all tracking-wide';
  
  const sizeStyles = {
    sm: 'text-xs px-2.5 py-0.5',
    md: 'text-xs font-semibold px-3 py-1'
  };

  const variantStyles: Record<BadgeVariant, string> = {
    terracotta: 'bg-[#C85A32]/10 text-[#C85A32] border border-[#C85A32]/20',
    forest: 'bg-[#1E3A2F]/10 text-[#1E3A2F] border border-[#1E3A2F]/20',
    sand: 'bg-[#E6DFD3] text-[#71321F] border border-[#D4C8B5]',
    charcoal: 'bg-[#222222] text-[#FDFBF7] border border-[#333333]',
    gold: 'bg-amber-100 text-amber-900 border border-amber-300',
    outline: 'bg-transparent text-[#222222] border border-[#D4C8B5]',
    demo: 'bg-[#C85A32] text-white font-mono text-[10px] tracking-widest uppercase shadow-sm'
  };

  return (
    <span className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}>
      {icon && <span className="shrink-0">{icon}</span>}
      {children}
    </span>
  );
};
