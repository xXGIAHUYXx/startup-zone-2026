import React from 'react';
import { QrCode, CheckCircle2, Clock, ShieldCheck, UserCheck, Sparkles, AlertCircle, Award } from 'lucide-react';
import type { CreativePassportRecord } from '../../types';

interface CreativePassportCardProps {
  passport: CreativePassportRecord;
  className?: string;
}

export const CreativePassportCard: React.FC<CreativePassportCardProps> = ({
  passport,
  className = ''
}) => {
  const isQcPassed = passport.qcStatus === 'dat_chuan';
  const isQcFailed = passport.qcStatus === 'can_xu_ly';
  const isApproved = !!passport.approverName;
  const isCompleted = !!passport.completedDate;

  return (
    <div className={`rounded-2xl border-2 border-[#C85A32]/40 bg-gradient-to-br from-[#FAF8F5] via-white to-[#FDF6F3] p-6 sm:p-7 shadow-xs relative overflow-hidden ${className}`}>
      
      {/* Background seal watermark */}
      <div className="absolute -right-8 -bottom-8 w-44 h-44 rounded-full border-8 border-[#C85A32]/5 flex items-center justify-center font-heritage text-5xl text-[#C85A32]/5 font-bold pointer-events-none select-none">
        MIVL
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#E6DFD3] pb-4 mb-5 gap-3">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-[#1E3A2F] text-amber-200 flex items-center justify-center font-heritage text-xl font-bold shadow-xs shrink-0">
            CP
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono tracking-widest text-[#C85A32] uppercase font-bold">
                HỒ SƠ GIAO DỊCH & SÁNG TẠO
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
                Khởi tạo ngày {passport.createdAt}
              </span>
            </div>
            <h4 className="font-heritage text-xl sm:text-2xl font-bold text-[#1E3A2F]">
              Creative Passport — {passport.title}
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="text-xs font-mono px-3 py-1.5 rounded-lg bg-[#1E3A2F]/10 text-[#1E3A2F] font-bold border border-[#1E3A2F]/20">
            {passport.passportId}
          </span>
        </div>
      </div>

      {/* Passport Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs sm:text-sm mb-5">
        
        {/* Section 1: Thông tin giao dịch & Khách hàng */}
        <div className="p-4 rounded-xl bg-white border border-[#E6DFD3] space-y-2">
          <div className="flex items-center gap-1.5 text-[#1E3A2F] font-bold text-xs uppercase tracking-wider mb-1">
            <span className="w-2 h-2 rounded-full bg-[#1E3A2F]" />
            Lần 1: Xác Nhận Nhu Cầu
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Mã đơn hàng / Yêu cầu:</span>
            <strong className="text-[#222222] font-mono">{passport.orderId}</strong>
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Khách hàng xác nhận:</span>
            <strong className="text-[#222222]">{passport.clientName} {passport.clientOrg ? `(${passport.clientOrg})` : ''}</strong>
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Thời hạn mong muốn:</span>
            <span className="text-[#444444] font-medium">{passport.targetDate}</span>
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Nội dung nhu cầu:</span>
            <p className="text-[#555555] text-xs line-clamp-2">{passport.requirementSummary}</p>
          </div>
        </div>

        {/* Section 2: Phương án & Thiết kế đã duyệt */}
        <div className="p-4 rounded-xl bg-white border border-[#E6DFD3] space-y-2">
          <div className="flex items-center gap-1.5 text-[#C85A32] font-bold text-xs uppercase tracking-wider mb-1">
            <span className="w-2 h-2 rounded-full bg-[#C85A32]" />
            Lần 2: Phương Án Đã Duyệt
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Xưởng thực hiện:</span>
            <strong className="text-[#1E3A2F]">
              {passport.workshopName || 'Đang chờ phân công'}
            </strong>
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Phiên bản thiết kế / Chương trình:</span>
            <span className="font-mono text-[#C85A32] font-semibold">
              {passport.approvedDesignVersion || 'Chưa có dữ liệu'}
            </span>
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Người phê duyệt & Ngày chốt:</span>
            <span className="text-[#444444]">
              {isApproved 
                ? `${passport.approverName} (${passport.approvedDate})` 
                : 'Chưa có dữ liệu (Đang chờ khách duyệt)'}
            </span>
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Phạm vi đã xác nhận:</span>
            <p className="text-[#555555] text-xs line-clamp-2">
              {passport.approvedScope || 'Chưa xác lập'}
            </p>
          </div>
        </div>

        {/* Section 3: Nghiệm thu QC & Bàn giao */}
        <div className="p-4 rounded-xl bg-white border border-[#E6DFD3] space-y-2">
          <div className="flex items-center gap-1.5 text-emerald-800 font-bold text-xs uppercase tracking-wider mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-600" />
            Lần 3: Kiểm Tra QC & Bàn Giao
          </div>
          <div>
            <span className="text-[11px] text-[#888888] block">Kiểm định chất lượng (QC):</span>
            {isQcPassed ? (
              <div>
                <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                  <CheckCircle2 size={14} />
                  Đạt tiêu chuẩn hồ sơ đã duyệt
                </span>
                <span className="block text-[11px] text-[#666666] mt-0.5">
                  Bởi: {passport.qcCheckedBy} ({passport.qcCheckedAt})
                </span>
                {passport.qcNotes && (
                  <span className="block text-[11px] text-[#555555] italic">"{passport.qcNotes}"</span>
                )}
              </div>
            ) : isQcFailed ? (
              <span className="inline-flex items-center gap-1 text-red-700 font-semibold">
                <AlertCircle size={14} />
                Cần xử lý bổ sung: {passport.qcNotes}
              </span>
            ) : passport.qcStatus === 'dang_kiem_tra' ? (
              <span className="inline-flex items-center gap-1 text-amber-700 font-semibold">
                <Clock size={14} />
                Đang tiến hành kiểm tra
              </span>
            ) : (
              <span className="text-[#888888]">Chưa có dữ liệu (Chờ hoàn thành)</span>
            )}
          </div>

          <div className="pt-1 border-t border-black/5">
            <span className="text-[11px] text-[#888888] block">Người xác nhận nhận bàn giao:</span>
            <strong className="text-[#222222]">
              {passport.handoverConfirmedBy || 'Chưa có dữ liệu'}
            </strong>
          </div>

          <div>
            <span className="text-[11px] text-[#888888] block">Căn cứ bàn giao:</span>
            <span className="text-[#444444] font-medium">
              {passport.handoverBasis || 'Chưa có dữ liệu'}
            </span>
          </div>

          <div>
            <span className="text-[11px] text-[#888888] block">Ngày hoàn tất:</span>
            <span className="text-[#1E3A2F] font-semibold">
              {passport.completedDate || 'Đang chờ xác nhận'}
            </span>
          </div>
        </div>
      </div>

      {/* Notice (Mục III & VIII) */}
      <div className="p-3.5 bg-[#FAF8F5] rounded-xl border border-[#E6DFD3] flex items-start justify-between gap-3 text-xs text-[#555555]">
        <div className="flex items-start gap-2.5">
          <QrCode size={20} className="text-[#1E3A2F] shrink-0 mt-0.5" />
          <div>
            <strong className="text-[#1E3A2F] block">Mã QR tra cứu hồ sơ giao dịch và sáng tạo:</strong>
            <p className="text-[11px] leading-relaxed text-[#666666]">
              Creative Passport là hồ sơ số hóa lưu vết toàn bộ tiến trình từ xác nhận nhu cầu, phê duyệt phương án đến kiểm tra chất lượng và bàn giao giữa khách hàng, nghệ nhân Bát Tràng và nền tảng MADE IN VIETNAM LAB. <em>Hồ sơ này không phải là chứng nhận pháp lý về xuất xứ sản phẩm.</em>
            </p>
          </div>
        </div>
      </div>

      {/* Footer Status */}
      <div className="pt-3.5 mt-4 border-t border-[#E6DFD3] flex items-center justify-between text-xs text-[#666666]">
        <div className="flex items-center gap-1.5">
          <CheckCircle2 size={15} className="text-[#1E3A2F]" />
          <span>Hồ sơ đồng bộ trực tiếp theo quy trình Một hồ sơ — Ba lần xác nhận</span>
        </div>
        <span className="font-mono text-[11px] text-[#888888]">
          Hệ thống điều phối MADE IN VIETNAM LAB
        </span>
      </div>
    </div>
  );
};
