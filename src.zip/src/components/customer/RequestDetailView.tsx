import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import type { OrderRequest, HandoverRecord } from '../../types';
import { Button } from '../common/Button';
import { CreativePassportCard } from './CreativePassportCard';
import { 
  ArrowLeft, 
  CheckCircle2, 
  Clock, 
  MessageSquare, 
  Store, 
  ShieldCheck, 
  Award,
  Sparkles,
  FileCheck,
  Check,
  PackageCheck
} from 'lucide-react';

interface RequestDetailViewProps {
  request: OrderRequest;
  onBack: () => void;
  onOpenChat: () => void;
}

export const RequestDetailView: React.FC<RequestDetailViewProps> = ({
  request,
  onBack,
  onOpenChat
}) => {
  const { customerApprove, confirmHandover } = useApp();

  // Mốc 2: State phê duyệt mẫu & báo giá
  const [approverName, setApproverName] = useState(request.contactName);
  const [confirmedSampleOrSpecs, setConfirmedSampleOrSpecs] = useState(
    request.serviceType === 'gifts'
      ? `Đồng ý mẫu thiết kế ${request.ownerProposal?.designOrProgramVersion || 'VER-CHOT'} và quy cách khắc logo`
      : `Đồng ý chương trình workshop ${request.ownerProposal?.designOrProgramVersion || 'VER-CHOT'} và lịch hẹn`
  );
  const [isSampleConfirmed, setIsSampleConfirmed] = useState(false);

  // Mốc 3: State xác nhận nhận hàng
  const [clientReceivedNotes, setClientReceivedNotes] = useState('Đã nhận đủ và hoàn tất kiểm tra thực tế.');

  const handleApprove = () => {
    if (!isSampleConfirmed) return;
    customerApprove(request.id, {
      approvedBy: approverName || request.contactName,
      confirmedSampleOrSpecs,
      notes: 'Khách hàng xác nhận đồng ý mẫu thiết kế, báo giá và điều kiện hợp tác'
    });
  };

  const handleClientConfirmHandover = () => {
    const now = new Date();
    const formattedDate = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1).toString().padStart(2, '0')}/${now.getFullYear()}`;

    const handover: HandoverRecord = {
      confirmedBy: request.contactName,
      confirmedAt: formattedDate,
      method: 'client_online',
      documentBasis: 'Khách hàng xác nhận hoàn tất trực tuyến trên Customer Portal',
      notes: clientReceivedNotes,
      postFiringFollowupStatus: request.serviceType === 'workshop' 
        ? (request.artisanExecutionReport?.postFiringFollowup || 'Đã giao tại workshop hoặc lưu nung giao sau') 
        : undefined
    };

    confirmHandover(request.id, handover);
  };

  const getStatusText = (status: OrderRequest['status']) => {
    switch (status) {
      case 'cho_tiep_nhan':
        return 'Chờ tiếp nhận từ chuyên viên điều phối';
      case 'dang_tu_van':
        return 'Đang tư vấn và làm rõ thông số yêu cầu';
      case 'da_chuyen_xuong':
        return 'Đang đợi xưởng Bát Tràng phản hồi khả năng & báo giá';
      case 'cho_owner_kiem_tra':
        return 'Xưởng đã phản hồi • Điều phối viên đang kiểm tra phương án';
      case 'cho_khach_duyet':
        return 'Phương án & Báo giá đã sẵn sàng • Chờ bạn phê duyệt';
      case 'dang_thuc_hien':
        return request.serviceType === 'workshop' 
          ? 'Đang chuẩn bị tổ chức buổi workshop trải nghiệm' 
          : 'Đang tiến hành tạo hình và chế tác tại xưởng';
      case 'cho_owner_qc':
        return 'Xưởng đã báo xong • Điều phối viên đang kiểm tra chất lượng (QC)';
      case 'cho_khach_nghiem_thu':
        return 'QC Đạt chuẩn • Chờ bạn xác nhận nhận hàng hoặc hoàn tất dịch vụ';
      case 'can_xu_ly_qc':
        return 'Đang hiệu chỉnh chất lượng theo yêu cầu của Điều phối viên';
      case 'hoan_thanh':
        return 'Đã nghiệm thu kiểm định và bàn giao thành phẩm hoàn tất';
      case 'xuong_tu_choi':
        return 'Xưởng bận lịch • Điều phối viên đang chuyển xưởng khác';
      default:
        return status;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Back button & top bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E6DFD3]">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2.5 rounded-xl border border-[#D4C8B5] hover:bg-white text-[#444444] transition-colors cursor-pointer"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-[#C85A32]">{request.id}</span>
              <span className="text-xs text-[#888888]">| Gửi lúc: {request.createdAt}</span>
            </div>
            <h2 className="font-heritage text-2xl sm:text-3xl font-bold text-[#1E3A2F]">
              {request.title}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            icon={<MessageSquare size={14} />}
            onClick={onOpenChat}
            className="text-xs font-semibold"
          >
            Nhắn tin với chuyên viên điều phối
          </Button>
        </div>
      </div>

      {/* 3 Step Progress Tracking Bar (Chuẩn hóa theo Mục II) */}
      <div className="bg-white rounded-2xl p-6 border border-[#E6DFD3] shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold tracking-wider uppercase text-[#C85A32] block">
            TIẾN TRÌNH: MỘT HỒ SƠ — BA LẦN XÁC NHẬN
          </span>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#1E3A2F]/10 text-[#1E3A2F]">
            {getStatusText(request.status)}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Mốc 1: Xác nhận nhu cầu */}
          <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 space-y-1">
            <div className="flex items-center justify-between text-xs font-bold text-[#1E3A2F]">
              <span>Mốc 1: Xác Nhận Nhu Cầu</span>
              <CheckCircle2 size={16} className="text-emerald-700" />
            </div>
            <p className="text-xs text-[#666666]">
              Yêu cầu đã được bạn đối chiếu và gửi lên hệ thống.
            </p>
          </div>

          {/* Mốc 2: Thẩm định khả thi & Phê duyệt */}
          <div className={`p-4 rounded-xl border space-y-1 transition-all ${
            request.status === 'dang_thuc_hien' || request.status === 'cho_owner_qc' || request.status === 'cho_khach_nghiem_thu' || request.status === 'hoan_thanh'
              ? 'border-emerald-200 bg-emerald-50/50'
              : request.status === 'cho_khach_duyet'
              ? 'border-[#C85A32] bg-[#FDF6F3] ring-1 ring-[#C85A32]/40'
              : 'border-[#E6DFD3] bg-[#FAF8F5]'
          }`}>
            <div className="flex items-center justify-between text-xs font-bold text-[#1E3A2F]">
              <span>Mốc 2: Xác Nhận Khả Thi & Duyệt</span>
              {request.status === 'dang_thuc_hien' || request.status === 'cho_owner_qc' || request.status === 'cho_khach_nghiem_thu' || request.status === 'hoan_thanh' ? (
                <CheckCircle2 size={16} className="text-emerald-700" />
              ) : request.status === 'cho_khach_duyet' ? (
                <span className="text-xs text-[#C85A32] font-mono font-bold animate-pulse">Cần bạn duyệt</span>
              ) : (
                <Clock size={16} className="text-[#888888]" />
              )}
            </div>
            <p className="text-xs text-[#666666]">
              {request.status === 'cho_khach_duyet' 
                ? 'Phương án & báo giá đã chuẩn bị xong, chờ bạn duyệt.' 
                : request.clientApproval?.approved
                ? `Đã duyệt phiên bản ${request.clientApproval.approvedDesignVersion}`
                : 'Xưởng và Điều phối viên thẩm định năng lực & giá.'}
            </p>
          </div>

          {/* Mốc 3: Kiểm tra chất lượng & Bàn giao */}
          <div className={`p-4 rounded-xl border space-y-1 ${
            request.status === 'hoan_thanh'
              ? 'border-emerald-200 bg-emerald-50/50'
              : request.status === 'cho_khach_nghiem_thu'
              ? 'border-teal-200 bg-teal-50/50 ring-1 ring-teal-500/40'
              : 'border-[#E6DFD3] bg-[#FAF8F5]'
          }`}>
            <div className="flex items-center justify-between text-xs font-bold text-[#1E3A2F]">
              <span>Mốc 3: Xác Nhận Hoàn Tất</span>
              {request.status === 'hoan_thanh' ? (
                <CheckCircle2 size={16} className="text-emerald-700" />
              ) : request.status === 'cho_khach_nghiem_thu' ? (
                <span className="text-xs text-teal-800 font-bold animate-pulse">Chờ bạn xác nhận</span>
              ) : (
                <Award size={16} className="text-[#888888]" />
              )}
            </div>
            <p className="text-xs text-[#666666]">
              {request.status === 'hoan_thanh'
                ? 'Đã nghiệm thu đạt chuẩn và bàn giao hoàn tất.'
                : request.status === 'cho_khach_nghiem_thu'
                ? 'QC đã đạt chuẩn, chờ bạn xác nhận nhận hàng / hoàn tất.'
                : 'Kiểm tra chất lượng và nhận bàn giao.'}
            </p>
          </div>

        </div>
      </div>

      {/* ACTION BANNER WHEN WAITING FOR CUSTOMER APPROVAL (MỐC 2 - MỤC 2) */}
      {request.status === 'cho_khach_duyet' && request.ownerProposal && (
        <div className="bg-white rounded-2xl p-6 sm:p-7 border-2 border-[#C85A32] shadow-md space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#E6DFD3]">
            <div>
              <span className="text-xs font-mono font-bold text-[#C85A32] uppercase tracking-wider block">
                BƯỚC PHÊ DUYỆT BẮT BUỘC (MỐC 2)
              </span>
              <h3 className="font-heritage text-xl sm:text-2xl font-bold text-[#1E3A2F]">
                Phương Án Chế Tác & Báo Giá Trọn Gói Đã Sẵn Sàng
              </h3>
            </div>
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
              Chờ bạn phê duyệt
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
            <div className="p-4 bg-[#FAF8F5] rounded-xl border border-[#E6DFD3] space-y-1.5">
              <span className="text-[#888888] block text-xs">Xưởng thực hiện:</span>
              <strong className="text-[#1E3A2F] text-base">{request.assignedWorkshopName}</strong>
              <p className="text-xs text-[#555555]">
                {request.artisanResponse?.technicalNotes || 'Đã đối chiếu khả năng đáp ứng kỹ thuật và lịch nung.'}
              </p>
            </div>

            <div className="p-4 bg-[#FDF6F3] rounded-xl border border-[#C85A32]/30 space-y-1.5">
              <span className="text-[#888888] block text-xs">Tổng chi phí thanh toán trọn gói:</span>
              <strong className="text-xl font-bold text-[#C85A32] block">
                {request.ownerProposal.clientTotalPrice}
              </strong>
              <span className="text-xs text-[#666666] block">
                Lịch dự kiến: {request.ownerProposal.proposedSchedule}
              </span>
            </div>
          </div>

          <div className="p-4 bg-[#FAF8F5] rounded-xl border border-[#E6DFD3] space-y-2 text-xs sm:text-sm">
            <div className="flex justify-between items-center pb-1 border-b border-black/5">
              <span className="text-[#666666]">Mã phiên bản đã chốt:</span>
              <strong className="font-mono text-[#1E3A2F]">{request.ownerProposal.designOrProgramVersion}</strong>
            </div>
            <div>
              <span className="text-[#666666] block mb-0.5">Điều kiện & cam kết chất lượng:</span>
              <p className="text-[#333333] leading-relaxed">
                {request.ownerProposal.termsAndConditions}
              </p>
            </div>
          </div>

          {/* Explicit sample approval checkbox as required in Mục 2 */}
          <div className="p-4 bg-amber-50/80 rounded-xl border border-amber-200 space-y-3">
            <span className="text-xs font-bold text-amber-950 uppercase block">
              Xác Nhận Phê Duyệt Mẫu Thiết Kế & Báo Giá (Bắt Buộc)
            </span>

            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={isSampleConfirmed}
                onChange={(e) => setIsSampleConfirmed(e.target.checked)}
                className="mt-0.5 w-4 h-4 accent-[#C85A32]"
              />
              <span className="text-xs text-amber-900 leading-relaxed font-medium">
                {request.serviceType === 'gifts'
                  ? `Tôi xác nhận đồng ý mẫu thiết kế ${request.ownerProposal.designOrProgramVersion}, mức giá trọn gói và các thông số cá nhân hóa theo hồ sơ để xưởng bắt đầu chế tác.`
                  : `Tôi xác nhận đồng ý chương trình trải nghiệm ${request.ownerProposal.designOrProgramVersion}, mức giá trọn gói và lịch tổ chức theo hồ sơ để xưởng bắt đầu công tác chuẩn bị.`}
              </span>
            </label>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <span className="text-xs text-[#666666]">
              * Khi bạn bấm duyệt, đơn hàng sẽ chuyển sang trạng thái "Đang thực hiện".
            </span>

            <Button
              variant="terracotta"
              size="lg"
              icon={<CheckCircle2 size={18} />}
              onClick={handleApprove}
              disabled={!isSampleConfirmed}
              className={`text-sm font-bold shadow-sm ${!isSampleConfirmed ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              Phê duyệt phương án & Chốt điều kiện
            </Button>
          </div>
        </div>
      )}

      {/* CONFIRMED APPROVAL NOTICE WHEN DANG THUC HIEN */}
      {request.status === 'dang_thuc_hien' && (
        <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-200 flex items-center justify-between gap-3 text-xs sm:text-sm text-indigo-900">
          <div className="flex items-center gap-3">
            <CheckCircle2 size={20} className="text-indigo-700 shrink-0" />
            <div>
              <strong className="block text-indigo-950">
                Phương án đã được bạn phê duyệt ({request.clientApproval?.approvedDesignVersion})
              </strong>
              <span>
                {request.serviceType === 'workshop'
                  ? 'Xưởng đang hoàn tất công tác chuẩn bị nguyên vật liệu và không gian tiếp đón.'
                  : 'Xưởng đang tiến hành tạo hình đất sét, tráng men và chuẩn bị mẻ nung chín.'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* NOTICE WHEN ARTISAN REPORTED BUT OWNER IS DOING QC */}
      {request.status === 'cho_owner_qc' && (
        <div className="p-4 bg-teal-50 rounded-2xl border border-teal-200 flex items-center gap-3 text-xs sm:text-sm text-teal-900">
          <Clock size={20} className="text-teal-700 shrink-0" />
          <div>
            <strong className="block text-teal-950">
              Xưởng đã báo cáo hoàn tất thực hiện
            </strong>
            <span>
              Điều phối viên MADE IN VIETNAM LAB đang tiến hành kiểm tra chất lượng (QC) theo hồ sơ đã duyệt trước khi bàn giao cho bạn.
            </span>
          </div>
        </div>
      )}

      {/* ACTION BANNER WHEN WAITING FOR CUSTOMER HANDOVER CONFIRMATION (MỐC 3 - MỤC 1) */}
      {request.status === 'cho_khach_nghiem_thu' && (
        <div className="bg-white rounded-2xl p-6 sm:p-7 border-2 border-emerald-600 shadow-md space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E6DFD3]">
            <div>
              <span className="text-xs font-mono font-bold text-emerald-800 uppercase tracking-wider block">
                XÁC NHẬN BÀN GIAO & HOÀN TẤT DỊCH VỤ (MỐC 3)
              </span>
              <h3 className="font-heritage text-xl sm:text-2xl font-bold text-[#1E3A2F]">
                {request.serviceType === 'workshop' 
                  ? 'Buổi Workshop Đã Tổ Chức & QC Đạt Chuẩn' 
                  : 'Sản Phẩm Đã Kiểm Định QC & Sẵn Sàng Bàn Giao'}
              </h3>
            </div>
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
              Chờ bạn xác nhận
            </span>
          </div>

          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs sm:text-sm space-y-1">
            <p className="text-emerald-950">
              <strong>Kết quả kiểm định chất lượng (QC):</strong> Đạt tiêu chuẩn hồ sơ đã duyệt.
            </p>
            <p className="text-emerald-900 text-xs">
              Kiểm tra bởi: <em>{request.qcRecord?.inspectorName}</em> ({request.qcRecord?.inspectedAt})
            </p>
            <p className="text-xs text-[#555555] italic">
              "{request.qcRecord?.notes}"
            </p>
          </div>

          {request.serviceType === 'workshop' && request.artisanExecutionReport?.postFiringFollowup && (
            <div className="p-3 bg-[#FAF8F5] rounded-xl border border-[#E6DFD3] text-xs text-[#444444]">
              <strong>Theo dõi thành phẩm nung sau:</strong> {request.artisanExecutionReport.postFiringFollowup}
            </div>
          )}

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <span className="text-xs text-[#666666]">
              * Bằng việc xác nhận, bạn ghi nhận đã nhận bàn giao đầy đủ để hoàn tất đơn hàng.
            </span>

            <Button
              variant="forest"
              size="lg"
              icon={<PackageCheck size={18} />}
              onClick={handleClientConfirmHandover}
              className="text-sm font-bold shadow-sm"
            >
              {request.serviceType === 'workshop' 
                ? 'Xác nhận hoàn tất buổi trải nghiệm' 
                : 'Xác nhận đã nhận hàng & Hoàn tất đơn'}
            </Button>
          </div>
        </div>
      )}

      {/* COMPLETED BANNER */}
      {request.status === 'hoan_thanh' && (
        <div className="p-4 bg-[#1E3A2F]/10 rounded-2xl border border-[#1E3A2F]/20 flex items-center justify-between gap-3 text-xs sm:text-sm text-[#1E3A2F]">
          <div className="flex items-center gap-3">
            <CheckCircle2 size={20} className="text-[#1E3A2F] shrink-0" />
            <div>
              <strong className="block text-[#1E3A2F]">
                Đơn hàng đã hoàn thành và bàn giao trọn vẹn
              </strong>
              <span>
                Người xác nhận: <strong>{request.handoverRecord?.confirmedBy}</strong> vào ngày {request.handoverRecord?.confirmedAt}. Hồ sơ sáng tạo đã được lưu trữ hoàn tất.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* SECTION: LIVE CREATIVE PASSPORT */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-heritage text-xl font-bold text-[#1E3A2F] flex items-center gap-2">
            <FileCheck size={20} className="text-[#C85A32]" />
            <span>Hồ Sơ Sáng Tạo (Creative Passport)</span>
          </h3>
          <span className="text-xs text-[#888888]">
            Lưu vết tự động theo tiến trình hợp tác
          </span>
        </div>

        <CreativePassportCard passport={request.creativePassport} />
      </div>

    </div>
  );
};
