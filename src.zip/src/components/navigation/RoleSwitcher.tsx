import React, { useState } from 'react';
import type { UserRole } from '../../types';
import { SlidersHorizontal, Users, Store, Globe, X, RotateCcw, Check, Sparkles, Inbox } from 'lucide-react';

interface RoleSwitcherProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onSelectScenario?: (scenarioId: string) => void;
  onResetDemo?: () => void;
}

export const RoleSwitcher: React.FC<RoleSwitcherProps> = ({
  currentRole,
  onRoleChange,
  onSelectScenario,
  onResetDemo
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  const roles: { role: UserRole; title: string; subtitle: string; icon: any }[] = [
    {
      role: 'guest',
      title: 'Khách hàng (Trang chủ)',
      subtitle: 'Khám phá dịch vụ & gửi yêu cầu mới',
      icon: Globe
    },
    {
      role: 'customer',
      title: 'Khách hàng (Đơn hàng của tôi)',
      subtitle: 'Xem tiến độ, phản hồi giá & duyệt mẫu',
      icon: Users
    },
    {
      role: 'owner',
      title: 'Chủ nền tảng (Điều phối viên)',
      subtitle: 'Tiếp nhận đơn, chat tư vấn, chuyển xưởng',
      icon: Inbox
    },
    {
      role: 'artisan',
      title: 'Xưởng thủ công Bát Tràng',
      subtitle: 'Nhận đơn được chuyển, báo giá & làm mẻ',
      icon: Store
    }
  ];

  const scenarios = [
    {
      id: 'scen-an-nam',
      title: 'Kịch bản B: Quà tặng 20 bộ ly sứ men hỏa biến',
      desc: 'Lô 20 bộ ly: Khách 8tr, Xưởng 6tr, Phí Lab 2tr. Đang ở bước khách duyệt phương án.',
      targetRole: 'customer' as UserRole
    },
    {
      id: 'scen-sao-mai',
      title: 'Kịch bản A: Workshop làm gốm đoàn 20 người',
      desc: 'Đoàn 20 người: Khách 10tr, Xưởng 7tr, Phí Lab 3tr. Yêu cầu mới chờ Owner tiếp nhận.',
      targetRole: 'owner' as UserRole
    },
    {
      id: 'scen-artisan',
      title: 'Góc nhìn Xưởng: Tiếp nhận đơn được phân công',
      desc: 'Xem góc nhìn xưởng Bát Tràng thẩm định năng lực và đề xuất báo giá xưởng.',
      targetRole: 'artisan' as UserRole
    }
  ];

  const handleReset = () => {
    if (onResetDemo) {
      onResetDemo();
      setShowConfirmReset(false);
      setIsOpen(false);
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 select-none">
      {/* Floating Compact Toggle Pill */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 bg-[#162E25]/95 hover:bg-[#162E25] text-white backdrop-blur-md px-3.5 py-2.5 rounded-full shadow-xl hover:shadow-2xl border border-white/20 text-xs font-medium transition-all duration-200 hover:scale-105 cursor-pointer group"
          title="Chuyển đổi vai trò trải nghiệm"
        >
          <SlidersHorizontal size={14} className="text-[#C85A32] group-hover:rotate-45 transition-transform" />
          <span>Chế độ trải nghiệm (3 vai trò)</span>
          <span className="w-2 h-2 rounded-full bg-[#C85A32] animate-pulse" />
        </button>
      )}

      {/* Pop-up Panel when opened */}
      {isOpen && (
        <div className="w-88 sm:w-96 bg-[#FAF8F5] rounded-2xl shadow-2xl border border-[#D4C8B5] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
          {/* Header */}
          <div className="p-4 bg-[#162E25] text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Sparkles size={16} className="text-[#C85A32]" />
              <div>
                <h4 className="font-heritage text-base font-bold leading-tight">
                  Chuyển Đổi 3 Vai Trò
                </h4>
                <p className="text-[11px] text-white/70">
                  Khách hàng • Điều phối viên • Xưởng Bát Tràng
                </p>
              </div>
            </div>
            <button
              onClick={() => { setIsOpen(false); setShowConfirmReset(false); }}
              className="p-1 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto">
            {/* Role Switching */}
            <div>
              <span className="text-[11px] font-mono uppercase tracking-wider text-[#777777] font-semibold block mb-2">
                Chọn vai trò để thao tác:
              </span>
              <div className="space-y-1.5">
                {roles.map((r) => {
                  const Icon = r.icon;
                  const isActive = currentRole === r.role;
                  return (
                    <button
                      key={r.role}
                      onClick={() => {
                        onRoleChange(r.role);
                      }}
                      className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#1E3A2F] text-white border-[#1E3A2F] shadow-xs'
                          : 'bg-white text-[#222222] border-[#E6DFD3] hover:border-[#C85A32]/50 hover:bg-[#FDFBF7]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-lg ${isActive ? 'bg-white/10 text-white' : 'bg-black/5 text-[#555555]'}`}>
                          <Icon size={16} />
                        </div>
                        <div>
                          <strong className="text-xs font-semibold block leading-tight">
                            {r.title}
                          </strong>
                          <span className={`text-[11px] ${isActive ? 'text-white/70' : 'text-[#777777]'}`}>
                            {r.subtitle}
                          </span>
                        </div>
                      </div>
                      {isActive && <Check size={16} className="text-[#C85A32] shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quick Scenario Launcher */}
            <div>
              <span className="text-[11px] font-mono uppercase tracking-wider text-[#777777] font-semibold block mb-2">
                Nạp kịch bản mẫu nhanh:
              </span>
              <div className="space-y-1.5">
                {scenarios.map((scen) => (
                  <button
                    key={scen.id}
                    onClick={() => {
                      if (onSelectScenario) onSelectScenario(scen.id);
                      setIsOpen(false);
                    }}
                    className="w-full p-2.5 rounded-xl bg-white hover:bg-[#FDF6F3] border border-[#E6DFD3] hover:border-[#C85A32]/40 text-left transition-all cursor-pointer group"
                  >
                    <strong className="text-xs font-semibold text-[#1E3A2F] group-hover:text-[#C85A32] block leading-tight mb-0.5">
                      {scen.title}
                    </strong>
                    <p className="text-[11px] text-[#666666] leading-snug">
                      {scen.desc}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Reset Data Confirmation */}
            <div className="pt-2 border-t border-[#E6DFD3]">
              {!showConfirmReset ? (
                <button
                  onClick={() => setShowConfirmReset(true)}
                  className="w-full py-2.5 px-3 rounded-xl border border-dashed border-[#D4C8B5] hover:border-red-400 text-[#777777] hover:text-red-600 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw size={13} />
                  <span>Đặt lại toàn bộ dữ liệu (Về trạng thái trống)</span>
                </button>
              ) : (
                <div className="p-3 bg-red-50 rounded-xl border border-red-200 text-xs space-y-2">
                  <p className="text-red-900 font-semibold leading-snug">
                    Xác nhận xóa toàn bộ đơn hàng và tin nhắn chat trong bộ nhớ trình duyệt?
                  </p>
                  <div className="flex gap-2 justify-end">
                    <button
                      onClick={() => setShowConfirmReset(false)}
                      className="px-2.5 py-1 rounded-lg bg-white border border-[#D4C8B5] text-[#555555] text-xs cursor-pointer"
                    >
                      Hủy
                    </button>
                    <button
                      onClick={handleReset}
                      className="px-2.5 py-1 rounded-lg bg-red-600 text-white text-xs font-bold cursor-pointer hover:bg-red-700"
                    >
                      Xóa dữ liệu
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="p-3 bg-[#FAF8F5] border-t border-[#E6DFD3] text-center">
            <button
              onClick={() => { setIsOpen(false); setShowConfirmReset(false); }}
              className="text-xs font-semibold text-[#1E3A2F] hover:text-[#C85A32] cursor-pointer"
            >
              Đóng bảng điều khiển
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
