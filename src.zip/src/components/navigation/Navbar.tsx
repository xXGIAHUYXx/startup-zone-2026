import React, { useState } from 'react';
import type { UserRole, ServiceType } from '../../types';
import { Button } from '../common/Button';
import { Menu, X, ArrowRight, Package } from 'lucide-react';

interface NavbarProps {
  currentRole: UserRole;
  onNavigateTab: (tab: string) => void;
  onOpenQuickRequest: (initialService?: ServiceType) => void;
  activeTab: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onNavigateTab,
  onOpenQuickRequest,
  activeTab
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (tab: string) => {
    onNavigateTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="bg-[#FDFBF7]/95 backdrop-blur-md border-b border-[#E6DFD3] sticky top-0 z-40 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between gap-4">
        
        {/* Brand Logo & Name */}
        <div 
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 cursor-pointer group select-none shrink-0"
        >
          {/* Ceramic Seal Icon */}
          <div className="w-10 h-10 rounded-xl bg-[#C85A32] text-white flex items-center justify-center font-serif text-lg font-bold shadow-sm group-hover:bg-[#B84A28] transition-colors">
            <span>VN</span>
          </div>
          <div>
            <span className="font-heritage text-xl sm:text-2xl font-bold tracking-tight text-[#1E3A2F] group-hover:text-[#C85A32] transition-colors block leading-none">
              MADE IN VIETNAM LAB
            </span>
            <span className="text-xs text-[#777777] tracking-wider mt-1 block">
              Gốm thủ công Bát Tràng
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2 text-sm font-medium text-[#444444]">
          <button
            onClick={() => handleNavClick('home')}
            className={`px-3.5 py-2 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'home' && currentRole === 'guest'
                ? 'text-[#C85A32] font-semibold bg-[#C85A32]/8'
                : 'hover:text-[#1E3A2F] hover:bg-black/5'
            }`}
          >
            Trang chủ
          </button>

          <button
            onClick={() => handleNavClick('workshop')}
            className={`px-3.5 py-2 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'workshop'
                ? 'text-[#C85A32] font-semibold bg-[#C85A32]/8'
                : 'hover:text-[#1E3A2F] hover:bg-black/5'
            }`}
          >
            Trải nghiệm làm gốm
          </button>

          <button
            onClick={() => handleNavClick('gifts')}
            className={`px-3.5 py-2 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'gifts'
                ? 'text-[#C85A32] font-semibold bg-[#C85A32]/8'
                : 'hover:text-[#1E3A2F] hover:bg-black/5'
            }`}
          >
            Quà tặng thủ công
          </button>

          <button
            onClick={() => handleNavClick('about')}
            className={`px-3.5 py-2 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'about'
                ? 'text-[#C85A32] font-semibold bg-[#C85A32]/8'
                : 'hover:text-[#1E3A2F] hover:bg-black/5'
            }`}
          >
            Về chúng tôi
          </button>

          <button
            onClick={() => handleNavClick('my-orders')}
            className={`px-3.5 py-2 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'my-orders' || currentRole === 'customer'
                ? 'text-[#1E3A2F] font-bold bg-[#1E3A2F]/8'
                : 'hover:text-[#1E3A2F] hover:bg-black/5'
            }`}
          >
            <Package size={15} className="text-[#C85A32]" />
            <span>Đơn hàng của tôi</span>
          </button>
        </nav>

        {/* Right Action CTA & Mobile Hamburger */}
        <div className="flex items-center gap-3">
          <Button
            variant="terracotta"
            size="md"
            icon={<ArrowRight size={15} />}
            iconPosition="right"
            onClick={() => onOpenQuickRequest()}
            className="hidden sm:inline-flex text-xs sm:text-sm font-semibold shadow-xs"
          >
            Gửi yêu cầu
          </Button>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-[#222222] hover:bg-black/5 transition-colors cursor-pointer"
            aria-label="Menu"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FDFBF7] border-b border-[#E6DFD3] px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top-2 duration-150">
          <button
            onClick={() => handleNavClick('home')}
            className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium ${
              activeTab === 'home' && currentRole === 'guest'
                ? 'bg-[#C85A32]/10 text-[#C85A32] font-semibold'
                : 'text-[#333333] hover:bg-black/5'
            }`}
          >
            Trang chủ
          </button>

          <button
            onClick={() => handleNavClick('workshop')}
            className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium ${
              activeTab === 'workshop'
                ? 'bg-[#C85A32]/10 text-[#C85A32] font-semibold'
                : 'text-[#333333] hover:bg-black/5'
            }`}
          >
            Trải nghiệm làm gốm
          </button>

          <button
            onClick={() => handleNavClick('gifts')}
            className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium ${
              activeTab === 'gifts'
                ? 'bg-[#C85A32]/10 text-[#C85A32] font-semibold'
                : 'text-[#333333] hover:bg-black/5'
            }`}
          >
            Quà tặng thủ công
          </button>

          <button
            onClick={() => handleNavClick('about')}
            className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium ${
              activeTab === 'about'
                ? 'bg-[#C85A32]/10 text-[#C85A32] font-semibold'
                : 'text-[#333333] hover:bg-black/5'
            }`}
          >
            Về chúng tôi
          </button>

          <button
            onClick={() => handleNavClick('my-orders')}
            className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium flex items-center gap-2 ${
              activeTab === 'my-orders' || currentRole === 'customer'
                ? 'bg-[#1E3A2F]/10 text-[#1E3A2F] font-bold'
                : 'text-[#333333] hover:bg-black/5'
            }`}
          >
            <Package size={16} className="text-[#C85A32]" />
            <span>Đơn hàng của tôi</span>
          </button>

          <div className="pt-3 border-t border-[#E6DFD3]">
            <Button
              variant="terracotta"
              size="md"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenQuickRequest();
              }}
              className="w-full justify-center text-sm font-semibold"
            >
              Gửi yêu cầu
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};
